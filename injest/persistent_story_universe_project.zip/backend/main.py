
from fastapi import FastAPI
from api import auth_routes, reader_routes, world_routes, story_routes

app = FastAPI(title="Persistent Story Universe API")

app.include_router(auth_routes.router, prefix="/auth")
app.include_router(reader_routes.router, prefix="/readers")
app.include_router(world_routes.router, prefix="/worlds")
app.include_router(story_routes.router, prefix="/stories")

@app.get("/health")
def health():
    return {"status": "ok"}

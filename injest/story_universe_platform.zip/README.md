
Persistent Story Universe Platform

Run API:

uvicorn api.main:app --reload

Start story:

POST /story/start

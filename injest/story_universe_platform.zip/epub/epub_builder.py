
class EPUBBuilder:

    def create_epub(self, scenes):
        # Placeholder EPUB generator
        filename = "story.epub"
        with open(filename, "w") as f:
            for s in scenes:
                f.write(s + "\n")
        return filename

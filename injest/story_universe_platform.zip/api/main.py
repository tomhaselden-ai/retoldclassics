
from fastapi import FastAPI
from story_engine.story_engine import StoryEngine

app = FastAPI(title="Persistent Story Universe API")

@app.get("/")
def root():
    return {"message": "Story Universe API running"}

@app.post("/story/start")
def start_story():
    engine = StoryEngine()
    story = engine.run_story()
    return {"story": story}

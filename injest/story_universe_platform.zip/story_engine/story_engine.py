
from utils.prompt_builder import build_prompt

class StoryGenerator:

    def generate(self, prompt: str) -> str:
        # Placeholder for LLM call
        return "Once upon a time in Silverwood Forest..."


class ScenePlanner:

    def plan(self):
        return [
            "introduction",
            "conflict",
            "attempt_to_solve",
            "resolution",
            "moral_lesson"
        ]


class StoryEngine:

    def __init__(self):
        self.generator = StoryGenerator()
        self.planner = ScenePlanner()

    def run_story(self):

        scenes = self.planner.plan()

        story = []

        for scene in scenes:
            prompt = build_prompt() + f"\nSCENE_STAGE: {scene}"
            text = self.generator.generate(prompt)
            story.append(text)

        return story

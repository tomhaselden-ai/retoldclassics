
CREATE TABLE universes (
    id SERIAL PRIMARY KEY,
    name TEXT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE characters (
    id SERIAL PRIMARY KEY,
    universe_id INTEGER REFERENCES universes(id),
    name TEXT,
    role TEXT,
    personality_traits JSONB,
    home_location TEXT
);

CREATE TABLE locations (
    id SERIAL PRIMARY KEY,
    universe_id INTEGER REFERENCES universes(id),
    name TEXT,
    description TEXT
);

CREATE TABLE children (
    id SERIAL PRIMARY KEY,
    name TEXT,
    age INTEGER,
    reading_level TEXT
);

CREATE TABLE stories (
    id SERIAL PRIMARY KEY,
    child_id INTEGER REFERENCES children(id),
    universe_id INTEGER REFERENCES universes(id),
    title TEXT,
    theme TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    epub_path TEXT
);

CREATE TABLE story_scenes (
    id SERIAL PRIMARY KEY,
    story_id INTEGER REFERENCES stories(id),
    scene_number INTEGER,
    scene_text TEXT,
    audio_path TEXT
);

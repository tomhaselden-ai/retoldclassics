
import json
from pathlib import Path

CONFIG_DIR = Path(__file__).resolve().parent.parent / "universe_config"

def load_json(name):
    with open(CONFIG_DIR / name) as f:
        return json.load(f)

def build_prompt():
    world = load_json("world.json")
    director = load_json("story_director.json")
    child = load_json("child_profile.json")
    scene = load_json("scene_state.json")

    return f"""
WORLD:
{world}

STORY DIRECTOR:
{director}

CHILD PROFILE:
{child}

SCENE:
{scene}

TASK:
Write a 5 minute bedtime story.
"""

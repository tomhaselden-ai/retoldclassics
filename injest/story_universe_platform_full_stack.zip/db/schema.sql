
CREATE TABLE universes(
 id SERIAL PRIMARY KEY,
 name TEXT,
 description TEXT
);

CREATE TABLE stories(
 id SERIAL PRIMARY KEY,
 child_id INTEGER,
 universe_id INTEGER,
 title TEXT,
 theme TEXT,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
